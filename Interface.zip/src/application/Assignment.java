package application;

import java.util.Date;

public class Assignment {
		public String Name;
		public String ClassName;
		public String AssignedDate;
		public String DueDate;
}
